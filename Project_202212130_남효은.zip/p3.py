# 프로젝트 문제 3번

class Queue:
    def __init__(self): #큐를 저장할 리스트를 초기화
        self.items = []
        
    def is_empty(self): # 큐가 비어 있는지 확인
        return self.items == []

    def enqueue(self, item):    #큐의 오른쪽 끝에 요소를 추가
        self.items.append(item)

    def dequeue(self):  # 큐의 앞에서 요소를 제거하고 그 값을 반환 
        return self.items.pop(0)

#입력처리  
N=int(input(""))
input_forest=[]
for i in range(N):
    row = list(map(int, input().split()))
    input_forest.append(row)

def problem3(input):
    bear_size = 2
    honeycomb_count = 0
    time = 0
    bear_x, bear_y = 0, 0

    # forest 리스트를 input 리스트로 초기화
    forest = [row[:] for row in input]

    # 곰의 초기 위치 찾기
    for i in range(N):
        for j in range(N):
            if forest[i][j] == 9:
                bear_x, bear_y = i, j
                forest[i][j] = 0
    print("곰의 초기 위치 x : {0}, y : {1}".format(bear_x, bear_y))

    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]     #상->하->좌->우

    #bfs를 이용하여 
    def bfs(start_x, start_y, size):
        queue = Queue()
        queue.enqueue((start_x, start_y))
        visited = [[0] * N for _ in range(N)]   #방문여부를 저장하는 리스트 
        visited[start_x][start_y] = 1
    
        dist = [[0] * N for _ in range(N)]      #거리를 저장하는 리스트  
        edible_honeycomb = []                   #먹을 수 있는 벌집의 위치와 거리를 저장하는 리스트 

        while not queue.is_empty():
            x, y = queue.dequeue()
            for dx, dy in directions:
                nx, ny = x + dx, y + dy
                if 0 <= nx < N and 0 <= ny < N and not visited[nx][ny]:     #만약 nx,ny가 숲 사이즈보다 작고 방문한 적이 없었다면,
                    if 0 <= forest[nx][ny] <= size:                              #그리고 곰의 크기보다 벌집사이즈가 작거나 같으면 이동 가능 
                        queue.enqueue((nx, ny))                             
                        visited[nx][ny] = 1
                        dist[nx][ny] = dist[x][y] + 1
                        if 0 < forest[nx][ny] < size:                       #게다가 벌집크기가 곰의 크기보다 더 작으면 edible_honeycomb리스트에 추가  
                            edible_honeycomb.append((dist[nx][ny], nx, ny))

        if edible_honeycomb:                                                    
            return sorted(edible_honeycomb)[0]                              #먹을 수 있는 벌집 중 거리가 가장 짧은 벌집의 위치를 반환 
        else:
            return None

    #곰이 벌집 찾기를 그만 둘때까지 반복 
    while True:
        honeycomb = bfs(bear_x, bear_y, bear_size)      #곰이 먹을 수 있는 가장 가까운 벌집위치를 반환 
        if not honeycomb:
            break

        dist, new_x, new_y = honeycomb      #튜플 
        time += dist    #거리 한 칸 이동에 1초씩 증가 
        bear_x, bear_y = new_x, new_y           #벌집이 있는 곳으로 곰의 위치 바꾸기
        forest[new_x][new_y] = 0                #해당 위치의 벌집 삭제  
        honeycomb_count += 1                    #벌집 먹은 개수 1증가 

        if honeycomb_count == bear_size:        #먹은 벌집 개수와 곰의 크기가 같으면 곰의 크기 1증가   
            bear_size += 1
            honeycomb_count = 0

    return time

result = problem3(input_forest)
print(result)
