# 프로젝트 문제 2번

input_string = input("괄호를 입력하시오. \n")

def problem2(input):
    stack=[]
    count_open=0
    count_close=0
    
    for char in input:
        if char == '(':         #여는 괄호 '('일 경우 스택에 추가 
            stack.append(char)
        elif char == ')':       #닫는 괄호 ')'일 경우  
            if stack and stack[-1] == '(':  #스택에 괄호가 들어있으면서, top에 여는 괄호가 들어있는 경우 
                stack.pop()
            else:
                count_close+=1          #짝이 없는 닫는 괄호 count
    count_open=len(stack)               #짝이 없는 여는 괄호 count

    result = count_open + count_close
    return result

result = problem2(input_string)

print(result)

