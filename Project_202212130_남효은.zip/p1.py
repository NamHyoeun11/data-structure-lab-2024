# 프로젝트 문제 1번

#입력처리 (100보다 작은 10의 배수) O(1)
input_number = []
for i in range(5):
    num=int(input(""))
    input_number.append(num)

def problem1(input):
    mean = 0            #평균
    median = 0          #중앙값 
    result = [0,0]

    #리스트의 모든 요소를 합산 O(n)
    mean = sum(input) / len(input)
    
    #리스트 정렬 O(nlogn)
    sorted_input = sorted(input)
    median = sorted_input[len(input)// 2]

    result[0] = mean
    result[1] = median
    return result

result = problem1(input_number)

print(result[0])        #평균값 출력 
print(result[1])        #중앙값 출력


